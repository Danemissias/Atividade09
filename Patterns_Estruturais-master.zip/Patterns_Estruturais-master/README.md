# Patterns_Estruturais
Atividade_9
